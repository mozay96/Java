public class StringTooLonngException extends Exception {
    public StringTooLonngException (String message)
    {
        super(message);
    }
}
